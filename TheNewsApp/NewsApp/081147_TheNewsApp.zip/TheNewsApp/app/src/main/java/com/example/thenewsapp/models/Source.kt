package com.example.thenewsapp.models

data class Source(
    val id: String,
    val name: String
)